@echo off
setlocal
set "EXE_NAME=%~n0"
set "EXE_NAME=%EXE_NAME:~4%"
set "NEXUS_EXE=%~dp0%EXE_NAME%.exe"
if not exist "%NEXUS_EXE%" (
  echo [NEXUS ERROR] Executable not found: "%NEXUS_EXE%"
  echo.
  pause
  exit /b 1
)
"%NEXUS_EXE%" %*
set "NEXUS_EXIT_CODE=%ERRORLEVEL%"
echo.
echo Program exited with code %NEXUS_EXIT_CODE%.
pause
exit /b %NEXUS_EXIT_CODE%
