NEXUS Paint - Windows x64
=========================
This desktop raster drawing application is written in the NEXUS language.
Launch NEXUS-Paint.exe. Keep the runtime DLLs in this same folder.
The ZIP contains the executable, editable NEXUS source, runtime DLLs and this note.
Source: https://github.com/fanxcz/nexus-lang/blob/main/examples/nexus_paint.nx
