Place your .nx programs in this folder. Drag a source file onto Run-NEXUS.bat or Build-NEXUS.bat.
