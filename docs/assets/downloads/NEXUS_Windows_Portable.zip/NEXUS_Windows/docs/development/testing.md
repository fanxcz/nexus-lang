# Testing

How to test NEXUS compiler and runtime.

## Test Types

| Type | Location | Command |
|------|----------|---------|
| Unit (C++) | `tests/test_*.cpp` | `ctest` |
| Integration | `tests/*.cmake` | `ctest` |
| Compiler | `tests/programs/` | `nexus test` |
| Examples | `examples/*.nx` | `nexus run --example` |

## Running Tests

```bash
# All tests (CMake)
ctest --test-dir build --output-on-failure

# Specific test
ctest --test-dir build -R nexus_tests

# Verbose
ctest --test-dir build -V

# NEXUS compiler tests
./build/nexus test

# With filter
./build/nexus test --filter "math::*"
```

## Writing C++ Unit Tests

```cpp
// tests/test_lexer.cpp
#include <gtest/gtest.h>
#include "compiler/lexer/lexer.hpp"

TEST(LexerTest, TokenizesIntegers) {
    Lexer lexer("42");
    auto tokens = lexer.tokenize();
    ASSERT_EQ(tokens.size(), 2);  // INT(42), EOF
    EXPECT_EQ(tokens[0].type, TokenType::Integer);
    EXPECT_EQ(tokens[0].value, "42");
}

TEST(LexerTest, TokenizesStrings) {
    Lexer lexer(R"("hello")");
    auto tokens = lexer.tokenize();
    ASSERT_EQ(tokens.size(), 2);
    EXPECT_EQ(tokens[0].type, TokenType::String);
    EXPECT_EQ(tokens[0].value, "hello");
}
```

## Writing NEXUS Tests

```nx
// tests/test_math.nx
import std.math

#[test]
fn test_add() {
    assert_eq!(math::add(2, 3), 5)
}

#[test]
fn test_sqrt() {
    assert_approx!(math::sqrt(16.0), 4.0, 0.001)
}

#[test]
#[should_panic]
fn test_div_by_zero() {
    let _ = 10 / 0
}
```

## Test Attributes

```nx
#[test]                    // Basic test
#[test]                    // With config
#[bench_config(runs = 100)]
fn bench_test() { ... }

#[test]                    // Expected to panic
#[should_panic]
fn test_panic() { ... }

#[test]                    // Ignored (manual run)
#[ignore]
fn test_slow() { ... }

#[test]                    // Timeout
#[timeout(5000)]  // ms
fn test_timeout() { ... }
```

## Assertions

```nx
assert!(condition)              // Panic if false
assert_eq!(left, right)         // Equality
assert_ne!(left, right)         // Inequality
assert_approx!(a, b, epsilon)   // Float comparison
assert_lt!(a, b)                // Less than
assert_gt!(a, b)                // Greater than
```

## Test Output

```
running 5 tests...
test test_add ... ok
test test_sqrt ... ok
test test_div_by_zero ... ok
test test_panic ... ok
test test_slow ... ignored

test result: ok. 4 passed; 0 failed; 1 ignored
```

## CI Integration

```yaml
# .github/workflows/test.yml
- name: Run tests
  run: |
    cmake --preset=debug
    cmake --build --preset=debug
    ctest --test-dir build --output-on-failure
```

## Coverage

```bash
# Build with coverage
cmake --preset=coverage
cmake --build --preset=coverage

# Run tests
ctest --test-dir build

# Generate report
lcov --capture --directory build --output-file coverage.info
genhtml coverage.info --output-directory coverage-report
```

## Best Practices

1. **Test public API** - not implementation details
2. **One assertion per test** - easier debugging
3. **Descriptive names** - `test_add_positive_numbers`
4. **Fast tests** - unit tests < 100ms each
5. **Deterministic** - no random, no network, no time
6. **Isolated** - no shared state between tests