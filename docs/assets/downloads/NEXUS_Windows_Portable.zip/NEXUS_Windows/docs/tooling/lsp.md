# Language Server Protocol (LSP)

IDE integration via `nexus lsp`.

## Usage

```bash
# Start LSP server (stdio)
nexus lsp

# With TCP port (for remote)
nexus lsp --port 8080

# With log file
nexus lsp --log-file lsp.log
```

## Supported Features

| Feature | Status |
|---------|--------|
| Completion | ✅ |
| Hover | ✅ |
| Go to Definition | ✅ |
| Go to Declaration | ✅ |
| Find References | ✅ |
| Document Symbols | ✅ |
| Workspace Symbols | ✅ |
| Rename | ✅ |
| Format | ✅ |
| Diagnostics | ✅ |
| Code Actions | 🚧 |
| Inlay Hints | 🚧 |
| Semantic Tokens | 🚧 |

## Editor Setup

### VS Code

```json
// .vscode/settings.json
{
    "nexus.lsp.enable": true,
    "nexus.lsp.path": "nexus",  // or full path
    "nexus.lsp.args": ["lsp"],
    
    // Auto-start
    "[nexus]": {
        "editor.formatOnSave": true
    }
}
```

### Neovim (nvim-lspconfig)

```lua
require('lspconfig').nexus.setup {
    cmd = { 'nexus', 'lsp' },
    filetypes = { 'nexus' },
    root_dir = function(fname)
        return require('lspconfig.util').root_pattern('nexus.toml', '.git')(fname)
    end,
    settings = {
        nexus = {
            checkOnSave = true,
            formatOnSave = true,
        }
    }
}
```

### Helix

```toml
# ~/.config/helix/languages.toml
[[language]]
name = "nexus"
language-servers = ["nexus-lsp"]

[language-server.nexus-lsp]
command = "nexus"
args = ["lsp"]
file-types = ["nx"]
```

### Zed

```json
// ~/.config/zed/settings.json
{
    "lsp": {
        "nexus": {
            "command": { "path": "nexus", "args": ["lsp"] },
            "initialization_options": {}
        }
    }
}
```

## Configuration

```toml
# nexus.toml
[tool.lsp]
check_on_save = true
format_on_save = true
diagnostics_severity = "warning"  # "error" | "warning" | "info"
completion_detail = true
inlay_hints = true
```

## Protocol Details

```json
// Initialize request
{
  "initialize": {
    "rootUri": "file:///project",
    "capabilities": {
      "textDocument": {
        "completion": { "completionItem": { "snippetSupport": true } }
      }
    }
  }
}
```

## Troubleshooting

| Issue | Fix |
|-------|-----|
| LSP not starting | Check `nexus lsp` works in terminal |
| No completions | Ensure `nexus.toml` exists in project root |
| Slow indexing | Exclude `build/`, `vendor/`, `site/` in editor |
| Wrong diagnostics | Run `nexus check` to verify |

## Logs

```bash
# Enable debug logging
nexus lsp --log-level debug --log-file lsp.log

# VS Code: "nexus.lsp.trace": "verbose"
```