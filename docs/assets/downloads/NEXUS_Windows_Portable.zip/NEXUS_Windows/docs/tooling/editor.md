# Editor

Built-in code editor (`nexus editor`).

## Usage

```bash
# Open editor
nexus editor

# Open specific file
nexus editor src/main.nx

# Open at line
nexus editor src/main.nx:42
```

## Features

| Feature | Status |
|---------|--------|
| Syntax highlighting | ✅ |
| Line numbers | ✅ |
| Bracket matching | ✅ |
| Auto-indent | ✅ |
| Find/Replace | ✅ |
| Go to line | ✅ |
| Multiple cursors | 🚧 |
| Code folding | 🚧 |
| Minimap | 🚧 |
| Git integration | 🚧 |

## Keybindings

| Key | Action |
|-----|--------|
| `Ctrl+S` | Save |
| `Ctrl+O` | Open |
| `Ctrl+N` | New file |
| `Ctrl+F` | Find |
| `Ctrl+H` | Replace |
| `Ctrl+G` | Go to line |
| `Ctrl+/` | Toggle comment |
| `Tab` | Indent |
| `Shift+Tab` | Unindent |
| `Ctrl+Z` | Undo |
| `Ctrl+Y` | Redo |
| `Ctrl+X` | Cut line |
| `Ctrl+D` | Duplicate line |
| `Alt+Up/Down` | Move line |
| `F12` | Go to definition |
| `Shift+F12` | Find references |

## Configuration

```toml
# nexus.toml
[tool.editor]
font_family = "JetBrains Mono"
font_size = 14
theme = "dark"  # "dark" | "light" | "auto"
tab_size = 4
insert_spaces = true
line_numbers = true
minimap = false
auto_save = false
```

## Themes

```toml
# Custom theme
[tool.editor.theme.custom]
background = "#1a1a2e"
foreground = "#e0e0e0"
cursor = "#ffffff"
selection = "#3a3a5a"
line_number = "#666666"
keyword = "#c792ea"
string = "#ecc48d"
number = "#f78c6c"
comment = "#6a9955"
function = "#82aaff"
type = "#ffcb6b"
```

## Integration

```bash
# Open project in editor
nexus editor .

# Open with specific file
nexus editor src/main.nx

# Pipe to editor
cat file.nx | nexus editor -
```