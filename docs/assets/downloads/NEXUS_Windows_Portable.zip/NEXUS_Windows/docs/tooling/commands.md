# Tooling Commands

NEXUS includes a comprehensive set of development tools accessible via the `nexus` CLI.

## Command Reference

| Command | Description |
|---------|-------------|
| `nexus new` | Create new project from template |
| `nexus init` | Initialize project in current directory |
| `nexus build` | Build project |
| `nexus run` | Build and run project |
| `nexus check` | Type-check without codegen |
| `nexus clean` | Remove build artifacts |
| `nexus fmt` | Format source code |
| `nexus lint` | Lint source code |
| `nexus doc` | Generate documentation |
| `nexus bench` | Run benchmarks |
| `nexus test` | Run tests |
| `nexus pkg` | Package management |
| `nexus editor` | Open built-in code editor |
| `nexus lsp` | Start Language Server Protocol |
| `nexus doctor` | Diagnose environment |
| `nexus assets` | Manage project assets |
| `nexus info` | Show project info |
| `nexus completion` | Generate shell completions |

## Project Commands

### `nexus new`

```bash
# Create from template
nexus new MyGame --template game

# List templates
nexus new --list

# Options
nexus new MyApp --template app \
    --name "My Application" \
    --author "Your Name" \
    --license MIT \
    --git
```

Available templates: `app`, `game`, `paint`, `cli`, `library`, `editor`, `server`, `3d`

### `nexus init`

```bash
# Initialize in current directory
nexus init

# With options
nexus init --name my-lib --template library
```

### `nexus build`

```bash
# Debug build (default)
nexus build

# Release build
nexus build --release

# Specific target
nexus build --target x86_64-windows

# Verbose output
nexus build -v

# Parallel jobs
nexus build -j 8
```

### `nexus run`

```bash
# Build and run (debug)
nexus run

# Release build and run
nexus run --release

# Pass arguments to program
nexus run -- --my-arg value
```

### `nexus check`

```bash
# Fast type-checking without codegen
nexus check

# Check specific file
nexus check src/main.nx

# With all warnings
nexus check --all-warnings
```

### `nexus clean`

```bash
# Clean build directory
nexus clean

# Clean everything including vendor
nexus clean --all
```

## Code Quality Commands

### `nexus fmt`

```bash
# Format all source files
nexus fmt

# Format specific file
nexus fmt src/main.nx

# Check formatting (CI mode)
nexus fmt --check

# Write changes (default)
nexus fmt --write
```

### `nexus lint`

```bash
# Lint all source files
nexus lint

# Lint with specific rules
nexus lint --rule unused-variable --rule dead-code

# Output as JSON (for CI)
nexus lint --format json
```

### `nexus doc`

```bash
# Generate documentation for project
nexus doc

# Output directory
nexus doc --output docs/api

# Include private items
nexus doc --private

# Open in browser
nexus doc --open
```

## Development Commands

### `nexus bench`

```bash
# Run benchmarks
nexus bench

# Specific benchmark
nexus bench --bench matrix_multiply

# Number of runs
nexus bench --runs 10

# Output format
nexus bench --format json
```

### `nexus test`

```bash
# Run all tests
nexus test

# Run specific test
nexus test --test unit_tests

# Filter by pattern
nexus test --filter "math::*"

# Verbose
nexus test -v
```

### `nexus editor`

```bash
# Open built-in editor
nexus editor

# Open specific file
nexus editor src/main.nx
```

### `nexus lsp`

```bash
# Start LSP server (for IDE integration)
nexus lsp

# With specific options
nexus lsp --port 8080 --log-file lsp.log
```

## Package Commands

### `nexus pkg`

```bash
# Initialize package in current dir
nexus pkg init

# Add local package
nexus pkg add ../my-library

# Remove package
nexus pkg remove my-lib

# List packages
nexus pkg list

# Build all packages
nexus pkg build

# Publish to registry (future)
nexus pkg publish

# Update dependencies
nexus pkg update
```

## Utility Commands

### `nexus doctor`

```bash
# Diagnose environment
nexus doctor

# Verbose output
nexus doctor -v

# Check specific component
nexus doctor --check compiler
nexus doctor --check runtime
```

### `nexus assets`

```bash
# List assets
nexus assets list

# Add asset
nexus assets add sprite.png

# Remove asset
nexus assets remove old.png

# Import from directory
nexus assets import ./assets/
```

### `nexus info`

```bash
# Show project info
nexus info

# Show dependency tree
nexus info --tree

# Show build config
nexus info --config
```

### `nexus completion`

```bash
# Generate completions
nexus completion bash > /etc/bash_completion.d/nexus
nexus completion zsh > ~/.zsh/completions/_nexus
nexus completion fish > ~/.config/fish/completions/nexus.fish
nexus completion powershell > nexus.ps1
```

## Global Options

| Option | Description |
|--------|-------------|
| `-h, --help` | Show help |
| `-V, --version` | Show version |
| `-v, --verbose` | Verbose output |
| `-q, --quiet` | Quiet output |
| `--color <when>` | Color output: auto, always, never |
| `--config <path>` | Config file path |
| `--project-root <path>` | Project root directory |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error |
| 2 | Invalid usage |
| 3 | Build failed |
| 4 | Check failed |
| 5 | Test failed |
| 6 | Lint failed |
| 7 | Format check failed |

## Configuration

Tools can be configured via `nexus.toml`:

```toml
[tool.fmt]
indent_size = 4
max_line_length = 100
trailing_comma = true

[tool.lint]
unused_variables = "warn"
dead_code = "warn"
shadowing = "allow"

[tool.doc]
include_private = false
output_dir = "docs/api"
```