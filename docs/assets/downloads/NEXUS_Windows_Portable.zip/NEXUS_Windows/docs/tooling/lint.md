# Linter

Static analysis (`nexus lint`) catches bugs and enforces best practices.

## Usage

```bash
# Lint all files
nexus lint

# Lint specific file
nexus lint src/main.nx

# With specific rules
nexus lint --rule unused-variable --rule dead-code

# JSON output (for CI)
nexus lint --format json

# Fix auto-fixable issues
nexus lint --fix
```

## Rules

| Rule | Default | Description |
|------|---------|-------------|
| `unused-variable` | warn | Variables declared but not used |
| `dead-code` | warn | Code after return/break/continue |
| `shadowing` | allow | Variable shadows outer scope |
| `missing-docs` | allow | Public items without docs |
| `unused-import` | warn | Imported but not used |
| `deprecated` | warn | Use of deprecated APIs |
| `unsafe-block` | warn | `unsafe` without comment |
| `panic-in-fn` | allow | `panic!` in non-test code |
| `large-function` | allow | Functions > 50 lines |
| `too-many-args` | allow | Functions > 7 parameters |

## Configuration

```toml
# nexus.toml
[tool.lint]
unused-variable = "warn"
dead-code = "warn"
shadowing = "allow"
missing-docs = "deny"  # Error on missing docs for public API
unused-import = "warn"
deprecated = "warn"
unsafe-block = "warn"
panic-in-fn = "allow"
large-function = "warn"
too-many-args = "warn"

# Per-file overrides
[tool.lint.overrides."tests/*"]
unused-variable = "allow"
dead-code = "allow"
```

## Severity Levels

- `allow` - Ignore completely
- `warn` - Warning (default)
- `deny` - Error (fails build)

## Examples

```nx
// ❌ unused-variable
fn foo() {
    let x = 42;  // Warning: unused variable
}

// ✅ Fixed
fn foo() {
    let _x = 42;  // Prefix with _ to suppress
}

// ❌ dead-code
fn bar() -> i32 {
    return 1;
    println("unreachable");  // Warning: dead code
}

// ❌ shadowing
fn baz(x: i32) {
    let x = 10;  // Warning: shadows parameter
}

// ✅ Fixed
fn baz(x: i32) {
    let y = x + 10;
}
```

## Output Formats

```bash
# Human readable (default)
nexus lint
# src/main.nx:10:5: warning: unused variable `x`
#   |
# 10 |     let x = 42;
#   |     ^^^^^^^^^^^

# JSON
nexus lint --format json
# [{"file":"src/main.nx","line":10,"column":5,"level":"warning","code":"unused-variable","message":"unused variable `x`"}]

# SARIF (for GitHub Code Scanning)
nexus lint --format sarif > results.sarif
```

## CI Integration

```yaml
# .github/workflows/lint.yml
- name: Lint
  run: nexus lint --format json
```

## Suppressing Warnings

```nx
// Suppress specific warning for next line
#[allow(unused_variable)]
let x = 42;

// Suppress for entire block
#[allow(dead_code)]
fn test_only() {
    // ...
}
```