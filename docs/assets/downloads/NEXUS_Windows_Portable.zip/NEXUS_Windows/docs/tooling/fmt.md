# Formatter

Code formatter (`nexus fmt`) ensures consistent style across projects.

## Usage

```bash
# Format all files in project
nexus fmt

# Format specific file
nexus fmt src/main.nx

# Check formatting (CI mode - exits 1 if changes needed)
nexus fmt --check

# Write changes (default)
nexus fmt --write
```

## Style Rules

| Rule | Setting |
|------|---------|
| Indent | 4 spaces |
| Max line length | 100 chars |
| Braces | Same line (K&R) |
| Trailing commas | Always in multi-line |
| Spaces around operators | Yes |
| Spaces after commas | Yes |
| Blank lines between items | 1 |

## Configuration

```toml
# nexus.toml
[tool.fmt]
indent_size = 4
max_line_length = 100
trailing_comma = true
brace_style = "kr"  # "kr" | "allman"
spaces_around_operators = true
blank_lines_between_items = 1
```

## Before/After

```nx
// Before
fn add(a:i32,b:i32)->i32{a+b}
struct  Point{x:f32,y:f32,}

// After
fn add(a: i32, b: i32) -> i32 {
    a + b
}

struct Point {
    x: f32,
    y: f32,
}
```

## Integration

### VS Code

```json
// .vscode/settings.json
{
    "editor.formatOnSave": true,
    "[nexus]": {
        "editor.defaultFormatter": "nexus.nexus-fmt"
    }
}
```

### CLI / Git Hooks

```bash
# Pre-commit hook
echo 'nexus fmt --check' > .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit

# Or use with husky/lint-staged
npx lint-staged -- 'nexus fmt --write'
```

## Ignoring Files

```bash
# .fmtignore (same syntax as .gitignore)
generated/
vendor/
*.gen.nx
```