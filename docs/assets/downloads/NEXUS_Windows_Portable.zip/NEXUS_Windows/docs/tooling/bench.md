# Benchmarking

Performance benchmarking (`nexus bench`).

## Usage

```bash
# Run all benchmarks
nexus bench

# Run specific benchmark
nexus bench --bench matrix_multiply

# Number of runs
nexus bench --runs 10

# Warmup runs (excluded from results)
nexus bench --warmup 3

# Output format
nexus bench --format json
nexus bench --format csv

# Baseline comparison
nexus bench --baseline main
```

## Writing Benchmarks

```nx
// benches/my_bench.nx
import std.bench

#[bench]
fn bench_matrix_multiply(b: &mut Bencher) {
    let a = Matrix::random(100, 100)
    let c = Matrix::random(100, 100)
    
    b.iter(|| {
        let _ = a.multiply(&c)
    })
}

#[bench]
fn bench_string_concat(b: &mut Bencher) {
    let mut s = String::new()
    
    b.iter(|| {
        s.push_str("hello")
        s.push_str("world")
    })
    
    // Or with setup/teardown
    b.iter_with_setup(
        || String::new(),
        |s| {
            s.push_str("hello")
        }
    )
}

#[bench]
#[bench_config(runs = 100, warmup = 5)]
fn bench_alloc(b: &mut Bencher) {
    b.iter(|| {
        let _ = mem_alloc(1024)
    })
}
```

## Benchmark Function

```nx
struct Bencher {
    fn iter(&mut self, f: impl FnMut())
    fn iter_with_setup(&mut self, setup: impl FnMut() -> T, f: impl FnMut(T))
    fn iter_with_large_drop(&mut self, f: impl FnMut())
    
    // Configuration
    fn runs(&self) -> u32
    fn set_runs(&mut self, n: u32)
    fn warmup(&self) -> u32
    fn set_warmup(&mut self, n: u32)
}
```

## Output

```
running 3 benchmarks...
bench_matrix_multiply    10 runs:  12.45 ms ± 0.23 ms  (12.10..12.78)
bench_string_concat     100 runs:   0.87 µs ± 0.05 µs  (0.82..0.95)
bench_alloc            1000 runs:   0.12 µs ± 0.01 µs  (0.11..0.14)

Summary:
  bench_matrix_multiply: 12.45 ms/iter
  bench_string_concat:   0.87 µs/iter
  bench_alloc:           0.12 µs/iter
```

## JSON Output

```json
[
  {
    "name": "bench_matrix_multiply",
    "runs": 10,
    "mean_ns": 12450000,
    "std_dev_ns": 230000,
    "min_ns": 12100000,
    "max_ns": 12780000,
    "median_ns": 12420000,
    "throughput": "iter/s"
  }
]
```

## Comparing Baselines

```bash
# Save baseline
nexus bench --save-baseline main

# Compare against baseline
nexus bench --baseline main
```

```
bench_matrix_multiply:  12.45 ms → 11.98 ms  (-3.8%)  ✓ faster
bench_string_concat:    0.87 µs  → 0.91 µs   (+4.6%)  ✗ slower
```

## Best Practices

1. **Stable environment** - same hardware, no background tasks
2. **Enough runs** - at least 10, more for fast operations
3. **Warmup** - JIT/cache warmup (3-5 runs)
4. **Isolate** - each benchmark independent
5. **Realistic data** - use production-like inputs
6. **Measure what matters** - focus on hot paths