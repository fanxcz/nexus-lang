# Tooling

Development tools for formatting, linting, debugging, and more.

## In This Section

| Tool | Description |
|------|-------------|
| [Commands](commands.md) | All CLI commands reference |
| [Formatter](fmt.md) | Code formatting |
| [Linter](lint.md) | Static analysis |
| [Documentation Generator](doc.md) | API documentation |
| [Benchmarking](bench.md) | Performance benchmarks |
| [LSP](lsp.md) | Language Server Protocol |
| [Editor](editor.md) | Built-in code editor |

## Quick Reference

```bash
# Format code
nexus fmt

# Lint code
nexus lint

# Generate docs
nexus doc

# Run benchmarks
nexus bench --runs 10

# Start LSP server
nexus lsp

# Open editor
nexus editor
```