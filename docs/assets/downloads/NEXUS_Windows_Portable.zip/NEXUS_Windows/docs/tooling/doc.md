# Documentation Generator

Generate API documentation from source code (`nexus doc`).

## Usage

```bash
# Generate docs for current project
nexus doc

# Output directory
nexus doc --output docs/api

# Include private items
nexus doc --private

# Open in browser after generation
nexus doc --open

# Watch mode (regenerate on changes)
nexus doc --watch
```

## Doc Comments

```nx
/// Module documentation
/// 
/// This module provides mathematical utilities.
module math {
    /// Computes the square root.
    /// 
    /// # Arguments
    /// * `x` - Non-negative number
    /// 
    /// # Returns
    /// Square root of `x`
    /// 
    /// # Examples
    /// ```
    /// let result = math::sqrt(16.0);  // 4.0
    /// ```
    export fn sqrt(x: f64) -> f64 { ... }
    
    /// 2D vector.
    /// 
    /// # Fields
    /// * `x` - X coordinate
    /// * `y` - Y coordinate
    export struct Vec2 {
        x: f32,
        y: f32,
    }
}
```

## Comment Syntax

```nx
/// Outer doc comment (for item below)
fn public_fn() { }

fn inner_fn() {
    //! Inner doc comment (for containing item)
    //!
    //! This documents the module/function body.
}
```

## Markdown Support

```nx
/// # Heading
/// 
/// **Bold**, *italic*, `code`
/// 
/// - List item 1
/// - List item 2
/// 
/// ```nx
/// let x = 42
/// ```
/// 
/// [Link](https://example.com)
fn documented() { }
```

## Sections

```nx
/// Function description.
/// 
/// # Arguments
/// * `param1` - Description
/// * `param2` - Description
/// 
/// # Returns
/// Description of return value
/// 
/// # Errors
/// * `ErrorKind::NotFound` - When...
/// * `ErrorKind::Permission` - When...
/// 
/// # Panics
/// Panics if `param1` is negative.
/// 
/// # Safety
/// Caller must ensure `ptr` is valid.
/// 
/// # Examples
/// ```
/// let result = my_fn(1, 2);
/// assert_eq!(result, 3);
/// ```
fn my_fn(param1: i32, param2: i32) -> Result<i32, Error> { ... }
```

## Attributes

```nx
#[doc = "Custom doc string"]
fn with_attr() { }

#[doc(hidden)]  // Hide from generated docs
fn internal() { }

#[doc(alias = "old_name")]  // Search alias
fn renamed() { }
```

## Output

```
docs/api/
├── index.html          # Main page
├── math/               # Module
│   ├── index.html
│   ├── fn.sqrt.html
│   └── struct.Vec2.html
├── search_index.js     # Search
└── style.css
```

## CI Integration

```yaml
# .github/workflows/docs.yml
- name: Generate docs
  run: nexus doc --output site/api
- name: Deploy to Pages
  uses: peaceiris/actions-gh-pages@v3
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    publish_dir: ./site
```

## Best Practices

1. **Document all public APIs** - functions, structs, enums, constants
2. **Use examples** - they're tested as part of `nexus test`
3. **Keep it concise** - one paragraph summary, then details
4. **Document errors** - what can go wrong and why
5. **Link related items** - `See also: [other_fn]`