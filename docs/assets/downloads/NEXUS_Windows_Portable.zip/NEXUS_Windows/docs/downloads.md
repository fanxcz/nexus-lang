# Downloads

Download the Windows portable bundle and use the included scripts to run your `.nx` source files. The complete compiler source and documentation are available in the [GitHub repository](https://github.com/fanxcz/nexus).

<div class="grid cards" markdown>

-   :material-microsoft-windows: **NEXUS for Windows 10/11 x64**

    Portable folder with the compiler executable, runtime source, standard modules, example programs, and launch scripts.

    [Download Windows ZIP](assets/downloads/NEXUS_Windows_Portable.zip){ .md-button .md-button--primary }

    [SHA-256 checksum](assets/downloads/NEXUS_Windows_Portable.zip.sha256.txt)

-   :material-source-repository: **Full source**

    C++20 compiler, runtime, standard modules, tests, examples, templates, and the documentation website.

    [Open GitHub repository](https://github.com/fanxcz/nexus){ .md-button }

</div>

## Windows installation

1. Download and extract the ZIP to a normal folder, for example `C:\NEXUS`. Do not run it from inside the ZIP viewer.
2. Run `Install-Requirements.bat`. The script checks for LLVM/Clang and Microsoft C++ Build Tools and prints official install links if something is missing.
3. Run `Check-NEXUS-Toolchain.bat`. It compiles and launches a tiny native Windows program as a toolchain check.
4. Drag any `.nx` file onto `Run-NEXUS.bat` to compile and run it, or onto `Build-NEXUS.bat` to create an `.exe` beside the source file.

## Required tools for native compilation

- Windows 10/11 x64
- LLVM/Clang with `clang++.exe`
- Visual Studio Build Tools 2022 with **Desktop development with C++** and a Windows SDK

The installer uses ASCII-only batch wrappers and a PowerShell script to avoid `cmd.exe` code-page and quoting errors. Installation may require internet access and administrator approval for system components.

## Integrity

The SHA-256 file lets you verify that your ZIP matches the package published with this source version. After downloading, PowerShell can calculate the hash:

```powershell
Get-FileHash .\NEXUS_Windows_Portable.zip -Algorithm SHA256
```

Compare the `Hash` value with the checksum file.

## Platform note

The Windows launcher and included Windows executable have not been verified by this build environment on a native Windows machine. Please run the toolchain check after installing prerequisites; report issues through [GitHub Issues](https://github.com/fanxcz/nexus/issues).
