---
hide:
  - navigation
  - toc
---

# NEXUS

**A native programming language and application/game runtime.**

Build native applications with a compact language, an LLVM-based compiler, and a runtime for graphics, audio, input, ECS, physics, and UI.

[Download for Windows](assets/downloads/NEXUS_Windows_Portable.zip){ .md-button .md-button--primary }
[Read the quick start](getting-started/quickstart.md){ .md-button }
[View source on GitHub](https://github.com/fanxcz/nexus){ .md-button }

<div class="grid cards" markdown>

-   :material-speedometer: **Native compilation**

    Compiles `.nx` programs into native executables using LLVM/Clang.

-   :material-controller: **Game runtime**

    2D/3D graphics, audio, input, scenes, ECS, particles, and physics.

-   :material-tools: **Developer tooling**

    CLI, formatter, linter, package workflow, LSP foundations, and templates.

-   :material-microsoft-windows: **Windows portable bundle**

    Includes `nexus.exe`, runtime sources, examples, and drag-and-drop `.nx` launchers.

</div>

## Run an NEXUS program on Windows

1. Download and extract the [Windows portable package](assets/downloads/NEXUS_Windows_Portable.zip).
2. Run `Install-Requirements.bat` and follow the prompts. Native builds require LLVM/Clang and Microsoft C++ Build Tools with a Windows SDK.
3. Run `Check-NEXUS-Toolchain.bat` to verify that the toolchain can compile and launch a Windows executable.
4. Drag your `.nx` file onto `Run-NEXUS.bat` to compile and run it, or onto `Build-NEXUS.bat` to create an `.exe` beside the source.

Example source:

```nx
fn main() {
    print("Hello from NEXUS!")
}
```

## Start from source

```powershell
# Windows: install CMake, Ninja, LLVM, and Visual Studio C++ Build Tools
cmake -S . -B build -G Ninja -DNEXUS_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

```bash
# Linux (example Debian/Ubuntu prerequisites)
sudo apt-get install cmake ninja-build clang lld libsdl2-dev
cmake -S . -B build -G Ninja -DNEXUS_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

## Explore NEXUS

- [Installation and quick start](getting-started/installation.md)
- [Language reference](language/overview.md)
- [Runtime API](runtime/overview.md)
- [Standard library](std/overview.md)
- [CLI tools](tooling/commands.md)
- [Examples and game demos](examples/overview.md)
- [Source repository](https://github.com/fanxcz/nexus)
- [Report a bug](https://github.com/fanxcz/nexus/issues)

## Project status

NEXUS is under active development. Windows package scripts and website source are included in this repository, but the Windows binary itself still needs confirmation on a native Windows machine. Advanced language features and some runtime modules remain experimental; check the relevant documentation before relying on them in production.
