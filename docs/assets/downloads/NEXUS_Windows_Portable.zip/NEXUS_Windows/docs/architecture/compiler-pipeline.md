# Compiler Pipeline

NEXUS compiler follows a traditional multi-pass architecture targeting LLVM IR.

## Pipeline Overview

```
Source (.nx)
    │
    ▼
┌─────────────────┐
│     Lexer       │ ──► Tokens
└─────────────────┘
    │
    ▼
┌─────────────────┐
│     Parser      │ ──► AST (Abstract Syntax Tree)
└─────────────────┘
    │
    ▼
┌─────────────────┐
│  Semantic Check │ ──► Typed AST + Symbol Table
└─────────────────┘
    │
    ▼
┌─────────────────┐
│   Codegen       │ ──► LLVM IR
└─────────────────┘
    │
    ▼
┌─────────────────┐
│  LLVM Backend   │ ──► Native Binary (.exe, ELF, Mach-O)
└─────────────────┘
```

## Stages

### 1. Lexer (`compiler/lexer/`)

Converts source text into tokens.

**Files:**
- `lexer.cpp` — Main lexer implementation
- `token.hpp` — Token definitions

**Token Types:**
- Keywords: `fn`, `let`, `mut`, `if`, `else`, `while`, `for`, `match`, `struct`, `enum`, `module`, `import`, `export`, `return`, `break`, `continue`, `defer`, `unsafe`, `extern`, `const`, `type`, `impl`, `as`, `in`, `loop`, `deref`, `ref`, `sizeof`, `alignof`, `offsetof`, `cast`, `transmute`
- Literals: integer, float, string, char, bool
- Operators: `+`, `-`, `*`, `/`, `%`, `==`, `!=`, `<`, `>`, `<=`, `>=`, `&&`, `||`, `!`, `=`, `+=`, `-=`, `*=`, `/=`, `%=`, `->`, `.`, `..`, `...`, `::`, `:`, `;`, `,`, `(`, `)`, `[`, `]`, `{`, `}`, `|`, `&`, `^`, `~`, `<<`, `>>`
- Identifiers

**Output:** Vector of `Token` with location info (file, line, column).

### 2. Parser (`compiler/parser/`)

Builds AST from tokens using recursive descent.

**Files:**
- `parser.cpp` — Parser implementation
- `ast/` — AST node definitions

**AST Nodes:**
- `Module` — Top-level module
- `Function` — Function declaration/definition
- `Struct` / `Enum` — Type definitions
- `Statement` — `Let`, `Expr`, `Return`, `If`, `While`, `For`, `Match`, `Block`, `Defer`, `Break`, `Continue`
- `Expression` — `Binary`, `Unary`, `Call`, `Field`, `Index`, `Cast`, `Literal`, `Variable`, `Block`, `If`, `Match`, `Loop`, `StructLit`, `ArrayLit`
- `Type` — `Primitive`, `Pointer`, `Reference`, `Array`, `Slice`, `Struct`, `Enum`, `Function`, `Inferred`

**Features:**
- Operator precedence parsing
- Error recovery (continues after errors)
- Source location tracking

### 3. Semantic Analysis (`compiler/semantic/`)

Type checking, symbol resolution, and validation.

**Files:**
- `semantic.cpp` — Semantic analyzer
- `symbols.hpp` — Symbol table
- `types.hpp` — Type system

**Responsibilities:**
- Name resolution (variables, functions, types, modules)
- Type inference and checking
- Trait/interface checking (future)
- Borrow checking (planned)
- Constant evaluation
- Dead code detection
- Unused variable warnings

**Symbol Table:**
- Hierarchical scopes (module → function → block)
- Separate namespaces: types, values, modules
- Shadowing rules

**Type System:**
- Primitive types (bool, integers, floats, char, str)
- Pointer types (`*T`, `*mut T`)
- Reference types (`&T`, `&mut T`)
- Array types (`[T; N]`)
- Slice types (`[]T`)
- Struct types (named, with methods)
- Enum types (tagged unions)
- Function types
- Generic type parameters (partial)

### 4. Codegen (`compiler/codegen/`)

Emits LLVM IR from typed AST.

**Files:**
- `llvm_ir.cpp` — LLVM IR generation
- `builtins.hpp` — Builtin function lowering

**Lowering Strategy:**
- Functions → LLVM functions
- Structs → LLVM struct types
- Enums → tagged unions (i32 tag + payload)
- Closures → function pointers + captures (planned)
- Generics → monomorphization (in progress)

**Builtins:**
- Memory: `mem_alloc`, `mem_free`, `mem_copy`, `mem_set`
- Math: `sin`, `cos`, `sqrt`, `pow`, etc.
- I/O: `print`, `println`, `read_line`
- Runtime: `gfx_*`, `audio_*`, `input_*`, `ecs_*`

### 5. Driver (`compiler/driver/`)

Orchestrates the pipeline.

**Files:**
- `driver.cpp` — Main driver

**Responsibilities:**
- Command-line parsing
- File discovery and module graph
- Incremental compilation (planned)
- Diagnostic reporting
- Output artifact management

## Module System

```
project/
├── src/
│   ├── main.nx          # Root module
│   ├── game/
│   │   ├── mod.nx       # game module
│   │   └── player.nx    # game::player submodule
│   └── utils.nx         # utils module
```

**Resolution Order:**
1. Standard library (`std.*`)
2. Local modules (`game`, `utils`)
3. Dependencies (`vendor/*`)

## Incremental Compilation (Planned)

- Per-module caching
- Dependency tracking via file hashes
- LLVM IR caching
- Parallel compilation

## Error Handling

Diagnostics include:
- Error code (E0001, E0002, ...)
- Message
- Source location (file, line, column)
- Source snippet with caret
- Notes and suggestions

```text
error[E0308]: mismatched types
  --> src/main.nx:10:13
   |
10 |     let x: i32 = "hello";
   |             ^^^^^^^^^^^^ expected `i32`, found `str`
   |
   = note: expected type `i32`
            found type `str`
help: consider converting the string to an integer
   |
10 |     let x: i32 = "hello".parse()?;
   |                       ++++++++++++
```

## Testing

Compiler tests in `tests/`:
- Unit tests for each stage
- Integration tests (compile + run)
- Snapshot tests for diagnostics
- Performance benchmarks

Run with:
```bash
ctest --test-dir build --output-on-failure
```