# Installation

## Pre-built Binaries

Download the latest release for your platform from [GitHub Releases](https://github.com/fanxcz/nexus/releases).

### Linux (x86_64)

```bash
# Download and install
wget https://github.com/fanxcz/nexus/releases/latest/download/nexus-linux-x86_64.tar.gz
tar -xzf nexus-linux-x86_64.tar.gz
sudo mv nexus /usr/local/bin/
```

### Windows (x86_64)

Download `nexus-windows-x86_64.zip`, extract, and add to PATH.

### macOS (x86_64 / arm64)

```bash
# Using Homebrew (when available)
brew install fanxcz/tap/nexus

# Or download from releases
```

## Building from Source

### Prerequisites

| Dependency | Minimum Version | Notes |
|------------|----------------|-------|
| CMake | 3.20 | Required for build system |
| Ninja | 1.10 | Recommended generator |
| Clang/LLVM | 18 | Or MSVC 19.40+ on Windows |
| SDL2 | 2.28 | Development headers required |
| C++20 Compiler | clang 18 / GCC 13 / MSVC 19.40 | |

#### Ubuntu / Debian

```bash
sudo apt-get update && sudo apt-get install -y \
    cmake ninja-build clang-18 lld-18 \
    libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev
```

#### Arch Linux

```bash
sudo pacman -S cmake ninja clang lld sdl2 sdl2_image sdl2_mixer sdl2_ttf
```

#### Fedora

```bash
sudo dnf install cmake ninja-build clang lld SDL2-devel SDL2_image-devel SDL2_mixer-devel SDL2_ttf-devel
```

#### Windows (PowerShell)

```powershell
choco install cmake ninja llvm sdl2
# Or use vcpkg: vcpkg install sdl2 sdl2-image sdl2-mixer sdl2-ttf
```

#### macOS

```bash
brew install cmake ninja llvm sdl2 sdl2_image sdl2_mixer sdl2_ttf
```

### Build Steps

```bash
# Clone repository
git clone https://github.com/fanxcz/nexus.git
cd nexus

# Configure (using CMake presets)
cmake --preset=release

# Build
cmake --build --preset=release

# Run tests
ctest --test-dir build --output-on-failure

# Install (optional)
sudo cmake --install build
```

### Verify Installation

```bash
nexus --version
# Output: nexus 1.1.0
```

## IDE Integration

### VS Code

Install the **NEXUS Language Support** extension (when available) or configure manually:

1. Install [C/C++ Extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode.cpptools)
2. Open the nexus repository folder
3. Select a CMake preset (Ctrl+Shift+P → "CMake: Select Configure Preset")
4. Choose `release` or `debug`

The repository includes `.vscode/settings.json` for automatic configuration.

### CLion

1. Open the nexus repository folder
2. CLion will detect `CMakePresets.json` automatically
3. Select a preset from the CMake toolbar
4. Build and run

### Neovim / Vim

Use [nvim-lspconfig](https://github.com/neovim/nvim-lspconfig) with `clangd`:

```lua
require('lspconfig').clangd.setup {
    cmd = { "clangd", "--compile-commands-dir=build" }
}
```

Run `cmake --preset=release` to generate `compile_commands.json`.

## Shell Completion

```bash
# Bash
nexus completion bash > /etc/bash_completion.d/nexus

# Zsh
nexus completion zsh > ~/.zsh/completions/_nexus

# Fish
nexus completion fish > ~/.config/fish/completions/nexus.fish

# PowerShell
nexus completion powershell > nexus.ps1
```

## Troubleshooting

### Common Issues

**CMake cannot find LLVM/Clang**
```bash
# Set LLVM path explicitly
cmake -S . -B build -G Ninja \
    -DCMAKE_C_COMPILER=/usr/bin/clang-18 \
    -DCMAKE_CXX_COMPILER=/usr/bin/clang++-18 \
    -DLLVM_DIR=/usr/lib/llvm-18/lib/cmake/llvm
```

**SDL2 not found on Windows**
```powershell
# Use vcpkg
vcpkg install sdl2:x64-windows
cmake -S . -B build -G Ninja -DCMAKE_TOOLCHAIN_FILE=$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake
```

**Linker errors with LLD**
```bash
# Use mold linker on Linux (faster)
sudo apt-get install mold
cmake -S . -B build -G Ninja -DCMAKE_LINKER=mold
```

### Getting Help

- Check [GitHub Issues](https://github.com/fanxcz/nexus/issues) for known problems
- Run `nexus doctor` to diagnose your environment
- Open a [new issue](https://github.com/fanxcz/nexus/issues/new/choose) with the `bug` template