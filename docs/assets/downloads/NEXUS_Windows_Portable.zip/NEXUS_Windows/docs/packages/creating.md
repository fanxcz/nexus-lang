# Creating Packages

How to create and publish NEXUS packages.

## Package Structure

```
my-package/
├── nexus.toml          # Package manifest (required)
├── src/
│   ├── lib.nx          # Library entry point
│   └── *.nx            # Other modules
├── tests/              # Package tests
├── examples/           # Usage examples
├── README.md
├── LICENSE
└── CHANGELOG.md
```

## Manifest (`nexus.toml`)

```toml
[package]
name = "my-package"           # Required: lowercase, hyphens
version = "1.0.0"             # Required: SemVer
edition = "2026"              # Required
description = "My package"    # Recommended
license = "MIT"               # Recommended: SPDX
repository = "https://github.com/user/my-package"
homepage = "https://example.com"
documentation = "https://docs.example.com"
keywords = ["math", "geometry"]
categories = ["data-structures"]
authors = ["Name <email@domain.com>"]
readme = "README.md"

[build]
entry = "src/lib.nx"          # Library entry point
# target_cpu = "native"
# optimization = "speed"

[lib]
# Custom library settings
# doctest = true

[dependencies]
# Other packages this depends on
# other-pkg = { path = "../other-pkg" }
```

## Library Entry Point (`src/lib.nx`)

```nx
// src/lib.nx - Main library module
module my_package {
    // Re-export submodules
    export module math
    export module utils
    
    // Or export directly
    export const VERSION: str = "1.0.0"
    export fn init() { ... }
}

// Submodules
// src/math.nx
module math {
    export fn add(a: i32, b: i32) -> i32 { a + b }
    export struct Vec2 { x: f32, y: f32 }
}

// src/utils.nx
module utils {
    export fn clamp(x: f32, min: f32, max: f32) -> f32 { ... }
}
```

## Writing Tests

```nx
// tests/test_math.nx
import my_package

#[test]
fn test_add() {
    assert_eq!(my_package::math::add(2, 3), 5)
}

#[test]
fn test_vec2() {
    let v = my_package::math::Vec2::new(3.0, 4.0)
    assert_eq!(v.length(), 5.0)
}
```

## Building

```bash
# Build package
nexus build

# Run tests
nexus test

# Check formatting
nexus fmt --check

# Lint
nexus lint

# Generate docs
nexus doc
```

## Versioning

Follow [Semantic Versioning](https://semver.org/):

| Change | Version Bump |
|--------|--------------|
| Bug fix | Patch (1.0.0 → 1.0.1) |
| New feature (backward compatible) | Minor (1.0.0 → 1.1.0) |
| Breaking change | Major (1.0.0 → 2.0.0) |

```bash
# Update version in nexus.toml
# Then commit and tag
git tag v1.1.0
git push origin v1.1.0
```

## Publishing (Future)

```bash
# Login to registry
nexus pkg login

# Publish
nexus pkg publish

# Publish specific version
nexus pkg publish --version 1.1.0

# Dry run
nexus pkg publish --dry-run
```

## Private Registry

```toml
# nexus.toml
[registries]
my-company = { url = "https://pkg.company.com", token = "..." }
```

## Best Practices

1. **Minimal dependencies** - prefer stdlib
2. **Clear README** - installation, usage, examples
3. **Complete docs** - all public items documented
4. **Tests** - cover public API
5. **CHANGELOG** - track changes per version
6. **License** - include LICENSE file
7. **CI** - test on multiple platforms