#!/usr/bin/env bash
set -euo pipefail
cmake -S . -B build -G Ninja
cmake --build build -j"$(nproc)"
ctest --test-dir build --output-on-failure
