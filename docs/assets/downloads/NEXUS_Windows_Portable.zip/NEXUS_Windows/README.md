# NEXUS 1.1.0

[![CI](https://github.com/fanxcz/nexus/actions/workflows/build.yml/badge.svg)](https://github.com/fanxcz/nexus/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.1.0-blue.svg)](https://github.com/fanxcz/nexus/releases)
[![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20Windows%20%7C%20macOS-lightgrey.svg)](https://github.com/fanxcz/nexus)
[![C++ Standard](https://img.shields.io/badge/C%2B%2B-20-blue.svg)](https://en.cppreference.com/w/cpp/20)
[![LLVM](https://img.shields.io/badge/LLVM-18%2B-orange.svg)](https://llvm.org/)
[![Documentation](https://img.shields.io/badge/docs-online-brightgreen.svg)](https://fanxcz.github.io/nexus/)

NEXUS is a native programming language and application/game runtime. The compiler is developed in C++20 and emits LLVM IR/native binaries through Clang/LLVM. This repository contains the compiler source, runtime, standard modules, examples, templates, tests, and the documentation website.

**Website and downloads:** https://fanxcz.github.io/nexus/ · [Windows portable ZIP](https://fanxcz.github.io/nexus/assets/downloads/NEXUS_Windows_Portable.zip)

## What is working

- Native compiler pipeline: lexer -> parser -> semantic checking -> LLVM IR -> native binary.
- Project workflow: `new`, `init`, `build`, `run`, `check`, `clean`, `info`, `assets`, `doctor`.
- Tooling: `fmt`, `lint`, `doc`, `bench`, `editor`, `lsp`.
- Local package workflow: `nexus pkg init/add/remove/list/update/build/publish`.
- Runtime: memory allocation, files, environment, input, HTTP GET facade, lightweight JSON field extraction, dynamic SQLite runtime loading, SHA-256 helper, SDL2/OpenGL 2D/3D, audio, UI, ECS, scenes, particles and physics.
- Targets: Linux x86_64 is the primary development target. Windows/macOS CI jobs are included; native release validation remains required.

## Create a project

```bash
nexus new MyGame --template game
cd MyGame
nexus build
nexus run
```

## Standard modules

```nx
import std.io
import std.fs
import std.net
import std.json
import std.db
import std.memory
import std.crypto
```

## Tooling

```bash
nexus fmt
nexus lint
nexus doc
nexus bench --runs 5
nexus test
nexus editor
nexus lsp
```

## Package workflow

Local packages can be vendored into `vendor/` and locked in `nexus.lock`:

```bash
nexus pkg init
nexus pkg add ../my-library
nexus pkg list
nexus pkg build
nexus pkg publish
```

## Important limits in 1.1.0

The runtime/tooling foundation is production-oriented, but some advanced language features remain experimental or are still being designed: full generic monomorphization, trait dispatch, closures/async lowering, a full visual scene editor, and a complete JSON AST/HTTP server stack. They are isolated behind stable interfaces so they can be added without redesigning the project format.

## Nexus Paint

NEXUS includes a native editable raster canvas example and project template:

```bash
nexus new NexusPaint --template paint
cd NexusPaint
nexus build --release
nexus run
```

The Paint template supports a 1024x720 canvas, pencil, eraser, line, rectangle, flood fill, color palette, brush size, undo/redo, and BMP save/load.

## Graphics backend (1.1.0)

Nexus 2D applications use the SDL2 renderer by default. This keeps windowed, maximized and fullscreen layouts independent from an OpenGL compatibility profile. OpenGL is enabled lazily when a 3D frame is requested.

Useful window controls:

```nx
gfx_fullscreen(true)
gfx_fullscreen(false)
gfx_maximize()
gfx_restore()
print(gfx_backend())
```

Applications can use a stable virtual UI space with `gfx_set_ui_resolution()`; mouse coordinates are converted into the same logical coordinate system.

## Downloads

- **Windows portable ZIP:** [Download](https://fanxcz.github.io/nexus/assets/downloads/NEXUS_Windows_Portable.zip)
- **Documentation and website:** [NEXUS on GitHub Pages](https://fanxcz.github.io/nexus/)
- **Full source:** this repository; generated build output and editor caches are excluded.

## Documentation

- [Language Reference](https://fanxcz.github.io/nexus/language/)
- [Runtime API](https://fanxcz.github.io/nexus/runtime/)
- [Standard Library](https://fanxcz.github.io/nexus/std/)
- [Tooling](https://fanxcz.github.io/nexus/tooling/)
- [Examples](https://fanxcz.github.io/nexus/examples/)

## Building from Source

### Prerequisites

- CMake 3.20+
- Ninja
- Clang/LLVM 18+ (or MSVC 19.40+ on Windows)
- SDL2 development libraries

### Build

```bash
# Configure
cmake -S . -B build -G Ninja -DNEXUS_BUILD_TESTS=ON

# Build
cmake --build build

# Test
ctest --test-dir build --output-on-failure

# Run
./build/nexus --version
```

### Using CMake Presets (VS Code / CLion)

```bash
# List available presets
cmake --list-presets

# Configure with a preset
cmake --preset=release

# Build with a preset
cmake --build --preset=release
```

Available presets: `default`, `debug`, `release`, `relwithdebinfo`, `msvc`, `msvc-debug`, `coverage`, `sanitize-address`.

## Publishing the site

See [PUBLISH-TO-GITHUB-RU.md](PUBLISH-TO-GITHUB-RU.md) for Russian instructions to upload this version and enable GitHub Pages.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.

## Community

- [GitHub Issues](https://github.com/fanxcz/nexus/issues) - Bug reports, feature requests, questions
- [GitHub Discussions](https://github.com/fanxcz/nexus/discussions) - General discussion